
const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const response = await loginUser({ email, password });

        if (response.id) {
            localStorage.setItem("user", JSON.stringify(response));
            window.location.href = "dashboard.html";
        } else {
            alert("Correo o contraseña incorrectos");
        }
    });
}


const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const response = await registerUser({ name, email, password });

        if (response.id) {
            alert("Cuenta creada correctamente");
            window.location.href = "login.html";
        } else {
            alert("Error al registrarse: " + response);
        }
    });
}
