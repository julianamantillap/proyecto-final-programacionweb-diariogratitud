const user = JSON.parse(localStorage.getItem("user"));
const leavesContainer = document.getElementById("leavesContainer");
const createSection = document.getElementById("createSection");
const createBtn = document.getElementById("createTreeBtn");

async function loadTree() {
    try {
        const trees = await api.get(`/gratitudetrees/user/${user.id}`);

        if (trees.length === 0) {
            createSection.style.display = "block";
            return;
        }

        createSection.style.display = "none";

        const tree = trees[0];
        renderLeaves(tree.gratitudeWords);

    } catch (err) {
        console.error("Error cargando árbol:", err);
    }
}

function renderLeaves(words) {
    leavesContainer.innerHTML = "";

    words.forEach(word => {
        const leaf = document.createElement("div");
        leaf.classList.add("leaf");
        leaf.textContent = word;

       
        leaf.style.top = (50 + Math.random() * 180) + "px";
        leaf.style.left = (Math.random() * 70 + 10) + "%";

        leaf.onclick = () => openLeafModal(word);

        leavesContainer.appendChild(leaf);
    });
}

function openLeafModal(word) {
    document.getElementById("modalWord").textContent = word;
    document.getElementById("leafModal").classList.remove("hidden");
}

function closeLeafModal() {
    document.getElementById("leafModal").classList.add("hidden");
}

createBtn.onclick = async () => {
    try {
        await api.post("/gratitudetrees", {
            name: "Mi Árbol",
            gratitudeWords: ["Vida", "Salud", "Familia"],
            user: { id: user.id }
        });
        loadTree();
    } catch (err) {
        console.error("Error creando árbol:", err);
    }
};

loadTree();
