const API_URL = "http://localhost:8080/api/v1";



async function loginUser(credentials) {
    const res = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials)
    });
    return res.json();
}

async function registerUser(data) {
    const res = await fetch(`${API_URL}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });
    return res.json();
}



async function getAllGratitudes() {
    const res = await fetch(`${API_URL}/gratitudes`);
    return res.json();
}

async function createGratitude(data) {
    const res = await fetch(`${API_URL}/gratitudes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    if (!res.ok) {
        throw new Error("Error creando gratitud");
    }
    return res.json();
}



async function getLikesByGratitude(gratitudeId) {
    const res = await fetch(`${API_URL}/likes/gratitude/${gratitudeId}`);
    return res.json();
}

async function createLike(userId, gratitudeId) {
    const body = {
        user: { id: userId },
        gratitude: { id: gratitudeId }
    };

    const res = await fetch(`${API_URL}/likes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });
    return res.json();
}

async function deleteLike(userId, gratitudeId) {
    const res = await fetch(`${API_URL}/likes/user/${userId}/gratitude/${gratitudeId}`, {
        method: "DELETE"
    });
    return res.ok;
}



async function getCommentsByGratitude(gratitudeId) {
    const res = await fetch(`${API_URL}/comments/gratitude/${gratitudeId}`);
    return res.json();
}

async function createComment(userId, gratitudeId, text, author) {
    const body = {
        text,
        author,
        user: { id: userId },
        gratitude: { id: gratitudeId }
    };

    const res = await fetch(`${API_URL}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });
    return res.json();
}
