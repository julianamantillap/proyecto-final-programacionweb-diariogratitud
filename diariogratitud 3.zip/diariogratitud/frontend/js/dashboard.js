console.log("dashboard.js — limpio y corregido");


document.addEventListener("DOMContentLoaded", async () => {

    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) {
        window.location.href = "login.html";
        return;
    }

    
    document.getElementById("userName").textContent = user.name;
    document.getElementById("helloText").textContent = `Hola, ${user.name}`;

    document.getElementById("avatarInitials").textContent = user.name
        .split(" ")
        .map(n => n[0])
        .join("")
        .substring(0,2)
        .toUpperCase();

    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("user");
        window.location.href = "login.html";
    });

    const form = document.getElementById("newGratitudeForm");
    const textArea = document.getElementById("gratitudeText");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const text = textArea.value.trim();

        if (!text) return alert("Escribe tu gratitud ✨");

        const payload = {
            text,
            author: user.name,
            user: { id: user.id }
        };

        try {
            await createGratitude(payload);
            textArea.value = "";

            await loadFeed();
            await loadSidePanel();
            await updateTreeWithWord(text);

        } catch (err) {
            console.error("Error guardando gratitud:", err);
            alert("Hubo un error guardando la gratitud.");
        }
    });

 
    await loadFeed();
    await loadSidePanel();
    await buildTreeCard();
    await loadCapsules();
    await loadUserProfile();
});



async function getAllGratitudes() {
    const res = await fetch("http://localhost:8080/api/v1/gratitudes/simple");
    return res.json();
}

async function createGratitude(payload) {
    await fetch("http://localhost:8080/api/v1/gratitudes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });
}



async function loadFeed() {
    const feed = document.getElementById("feed");
    feed.innerHTML = "Cargando...";

    let list = [];
    try {
        list = await getAllGratitudes();
    } catch {
        feed.innerHTML = "Error cargando gratitudes.";
        return;
    }

    feed.innerHTML = "";
    if (list.length === 0) {
        feed.innerHTML = "<p>No hay gratitudes aún ✨</p>";
        document.getElementById("wordCloud").innerHTML =
            "<p>No hay suficientes palabras aún 💭</p>";
        return;
    }

    list.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

    buildWordCloud(list);

    for (const g of list) {
        feed.appendChild(await createPostCard(g));
    }
}



async function createPostCard(gratitude) {
    const user = JSON.parse(localStorage.getItem("user"));
    const card = document.createElement("div");
    card.className = "post-card";

   
    const header = document.createElement("div");
    header.className = "post-header";

    const avatar = document.createElement("div");
    avatar.className = "post-author-avatar";
    avatar.textContent = gratitude.author[0].toUpperCase();

    const headerText = document.createElement("div");
    const author = document.createElement("p");
    author.className = "post-author-name";
    author.textContent = gratitude.author;

    const date = document.createElement("p");
    date.className = "post-date";
    date.textContent = formatDate(gratitude.createdAt);

    headerText.appendChild(author);
    headerText.appendChild(date);
    header.appendChild(avatar);
    header.appendChild(headerText);

   
    const text = document.createElement("p");
    text.className = "post-text";
    text.textContent = gratitude.text;

    
    const actions = document.createElement("div");
    actions.className = "post-actions";

    const likeBtn = await buildLikeButton(gratitude, user);
    const commentBtn = buildCommentToggle(gratitude.id);

    actions.appendChild(likeBtn);
    actions.appendChild(commentBtn);

  
    const commentsSection = document.createElement("div");
    commentsSection.className = "comments-section";
    commentsSection.style.display = "none";
    commentBtn.section = commentsSection;

    card.appendChild(header);
    card.appendChild(text);
    card.appendChild(actions);
    card.appendChild(commentsSection);

    return card;
}



function formatDate(dateStr) {
    const d = new Date(dateStr);
    return d.toLocaleString("es-CO", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}


async function getLikesByGratitude(id) {
    const res = await fetch(`http://localhost:8080/api/v1/likes/gratitude/${id}`);
    return res.json();
}

async function createLike(userId, gratitudeId) {
    await fetch("http://localhost:8080/api/v1/likes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            user: { id: userId },
            gratitude: { id: gratitudeId }
        })
    });
}

async function deleteLike(userId, gratitudeId) {
    await fetch(`http://localhost:8080/api/v1/likes/user/${userId}/gratitude/${gratitudeId}`, {
        method: "DELETE"
    });
}

async function buildLikeButton(gratitude, user) {
    const btn = document.createElement("button");
    btn.className = "like-button";

    const heart = document.createElement("span");
    heart.className = "heart";
    heart.textContent = "♥";

    const likeCount = document.createElement("span");

    let likes = await getLikesByGratitude(gratitude.id);
    let count = Array.isArray(likes) ? likes.length : 0;

    let liked =
        Array.isArray(likes) &&
        likes.some(l => l.user && l.user.id === user.id);

    if (liked) btn.classList.add("liked");
    likeCount.textContent = count;

    btn.appendChild(heart);
    btn.appendChild(likeCount);

    btn.addEventListener("click", async () => {
        try {
            if (liked) {
            await deleteLike(user.id, gratitude.id);
                count--;
                btn.classList.remove("liked");
            } else {
                await createLike(user.id, gratitude.id);
                count++;
                btn.classList.add("liked");
            }
            liked = !liked;
            likeCount.textContent = count;
        } catch {
            alert("No se pudo actualizar el like");
        }
    });

    return btn;
}



async function getCommentsByGratitude(id) {
    const res = await fetch(`http://localhost:8080/api/v1/comments/gratitude/${id}`);
    return res.json();
}

async function createComment(userId, gratitudeId, text, author) {
    await fetch("http://localhost:8080/api/v1/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            text,
            author,
            user: { id: userId },
            gratitude: { id: gratitudeId }
        })
    });
}

function buildCommentToggle(gratitudeId) {
    const btn = document.createElement("button");
    btn.className = "comment-toggle";
    btn.textContent = "Ver comentarios";

    btn.addEventListener("click", async () => {
        const section = btn.section;

        if (section.style.display === "none") {
            section.style.display = "block";
            btn.textContent = "Ocultar comentarios";
            await loadCommentsForGratitude(gratitudeId, section);
        } else {
            section.style.display = "none";
            btn.textContent = "Ver comentarios";
        }
    });

    return btn;
}

async function loadCommentsForGratitude(gratitudeId, container) {
    container.innerHTML = "Cargando...";

    let comments = [];
    const user = JSON.parse(localStorage.getItem("user"));

    try {
        comments = await getCommentsByGratitude(gratitudeId);
    } catch {
        container.innerHTML = "No se pudieron cargar los comentarios.";
        return;
    }

    container.innerHTML = "";

    if (!comments.length) {
        container.innerHTML = "<p>No hay comentarios aún ✨</p>";
    } else {
        comments.forEach(c => {
            const item = document.createElement("div");
            item.className = "comment-item";
            item.innerHTML = `
                <span class="comment-author">${c.author}:</span>
                <span class="comment-text">${c.text}</span>
            `;
            container.appendChild(item);
        });
    }

    
    const form = document.createElement("form");
    form.className = "comment-form";

    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Escribe un comentario...";

    const btn = document.createElement("button");
    btn.type = "submit";
    btn.textContent = "Enviar";

    form.appendChild(input);
    form.appendChild(btn);
    container.appendChild(form);

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const text = input.value.trim();
        if (!text) return;

        await createComment(user.id, gratitudeId, text, user.name);
        input.value = "";
        await loadCommentsForGratitude(gratitudeId, container);
    });
}



function buildWordCloud(gratitudes) {
    const cloud = document.getElementById("wordCloud");
    cloud.innerHTML = "";

    const words = gratitudes
        .map(g => g.text)
        .join(" ")
        .toLowerCase()
        .replace(/[.,!?¿¡]/g, " ")
        .split(" ")
        .filter(w => w.length > 3);

    if (!words.length) {
        cloud.innerHTML = "<p>No hay suficientes palabras aún 💭</p>";
        return;
    }

    
    const freq = {};
    words.forEach(w => freq[w] = (freq[w] || 0) + 1);

    
    const entries = Object.entries(freq)
        .sort((a,b) => b[1] - a[1])
        .slice(0, 20);

    
    entries.forEach(([word, count]) => {
        const span = document.createElement("span");
        span.className = "cloud-word";
        span.textContent = word;

       
        const size = 14 + count * 6;
        span.style.fontSize = size + "px";

       
        span.style.left = (Math.random() * 80) + "%";
        span.style.top = (Math.random() * 80) + "%";

        
        span.style.transform = `rotate(${Math.random() * 20 - 10}deg)`;

        cloud.appendChild(span);
    });
}




async function loadSidePanel() {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return;

    await Promise.all([
        loadStreak(user.id),
        loadAchievements(user.id),
        loadPastEntries(user.id)
    ]);
}


async function loadStreak(userId) {
    const daysSpan = document.getElementById("streakDays");
    const dateSpan = document.getElementById("streakLastUpdate");

    try {
        const res = await fetch(`http://localhost:8080/api/v1/streaks/user/${userId}`);
        const list = await res.json();

        if (!Array.isArray(list) || !list.length) {
            daysSpan.textContent = "0 días";
            dateSpan.textContent = "Sin registros aún";
            return;
        }

        list.sort((a,b) => b.daysCount - a.daysCount);
        const streak = list[0];

        daysSpan.textContent = `${streak.daysCount} días`;

        if (streak.lastUpdate) {
            const d = new Date(streak.lastUpdate);
            dateSpan.textContent = "Última actualización: " + d.toLocaleDateString("es-CO");
        }

    } catch (err) {
        daysSpan.textContent = "0 días";
        dateSpan.textContent = "";
    }
}


async function loadAchievements(userId) {
    const ul = document.getElementById("achievementsList");
    ul.innerHTML = "Cargando...";

    try {
        const res = await fetch(`http://localhost:8080/api/v1/achievements/user/${userId}`);
        const list = await res.json();

        ul.innerHTML = "";

        if (!list.length) {
            ul.innerHTML = "<li class='empty-msg'>Todavía no hay logros registrados.</li>";
            return;
        }

        list.sort((a,b) => new Date(b.date) - new Date(a.date));

        list.forEach(a => {
            const li = document.createElement("li");
            li.innerHTML = `
                <span class="text">${a.description}</span>
                <span class="date">${new Date(a.date).toLocaleDateString("es-CO")}</span>
            `;
            ul.appendChild(li);
        });

    } catch {
        ul.innerHTML = "<li class='empty-msg'>No se pudieron cargar los logros.</li>";
    }
}



async function loadPastEntries(userId) {
    const ul = document.getElementById("pastEntriesList");
    ul.innerHTML = "Cargando...";

    try {
        const res = await fetch(`http://localhost:8080/api/v1/pastentries/user/${userId}`);
        const list = await res.json();

        ul.innerHTML = "";

        if (!list.length) {
            ul.innerHTML = "<li class='empty-msg'>Aún no tienes recuerdos guardados.</li>";
            return;
        }

        list.sort((a,b) => new Date(b.publishedAt) - new Date(a.publishedAt));

        list.forEach(e => {
            const li = document.createElement("li");
            li.innerHTML = `
                <span class="text">${e.title}</span>
                <span class="date">${new Date(e.publishedAt).toLocaleString("es-CO")}</span>
            `;
            ul.appendChild(li);
        });

    } catch {
        ul.innerHTML = "<li class='empty-msg'>No se pudieron cargar las entradas.</li>";
    }
}



async function fetchTreeByUser(userId) {
    const res = await fetch(`http://localhost:8080/api/v1/gratitudetrees/user/${userId}`);
    return res.json();
}

async function createTree(userId) {
    const res = await fetch("http://localhost:8080/api/v1/gratitudetrees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name: "Mi Árbol de Gratitud",
            gratitudeWords: ["vida", "salud", "familia"],
            user: { id: userId }
        })
    });
    return res.json();
}

async function updateTree(tree) {
    const res = await fetch(`http://localhost:8080/api/v1/gratitudetrees/${tree.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(tree)
    });
    return res.json();
}



async function updateTreeWithWord(text) {
    const user = JSON.parse(localStorage.getItem("user"));
    const words = text.toLowerCase().split(" ").filter(w => w.length > 3);

    let trees = await fetchTreeByUser(user.id);
    let tree = trees.length === 0 ? await createTree(user.id) : trees[0];

    tree.gratitudeWords.push(...words);

    await updateTree(tree);
    await buildTreeCard();
}



async function buildTreeCard() {
    const container = document.getElementById("treeCardContainer");
    if (!container) return;

    container.innerHTML = "<p>Cargando árbol…</p>";

    const user = JSON.parse(localStorage.getItem("user"));
    let trees = await fetchTreeByUser(user.id);

    let tree = trees.length === 0 ? await createTree(user.id) : trees[0];

    container.innerHTML = `
        <div class="tree-card">
            <h3>🌳 Mi Árbol de Gratitud</h3>
            <p class="tree-sub">${tree.gratitudeWords.length} hojas</p>
            <button class="btn-primary" id="openTreeBtn">Ver árbol</button>
        </div>
    `;

    document.getElementById("openTreeBtn")
        .addEventListener("click", () => openTreeModal(tree));
}



function openTreeModal(tree) {
    const modal = document.getElementById("treeModal");
    const leavesContainer = document.getElementById("treeLeaves");

    modal.classList.remove("hidden");
    leavesContainer.innerHTML = "";

    drawLeaves(tree.gratitudeWords);
}



function closeTreeModal() {
    document.getElementById("treeModal").classList.add("hidden");
}



function drawLeaves(words) {

    const leavesContainer = document.getElementById("treeLeaves");
    leavesContainer.innerHTML = "";

   
    const areaWidth = 360;
    const areaHeight = 420;

    words.forEach((word, index) => {
        const leaf = document.createElement("div");
        leaf.className = "tree-leaf";
        leaf.textContent = word;

       
        let x = Math.random() * areaWidth;
        let y = Math.random() * areaHeight;

       
        if (y > 300) y = Math.random() * 250;

       
        const centerX = areaWidth / 2;
        const distToCenter = Math.abs(x - centerX);

        if (distToCenter > 150) {
            x = centerX + (Math.random() * 120 - 60);
        }

       
        leaf.style.left = x + "px";
        leaf.style.top = y + "px";

        const size = 12 + Math.random() * 7;
        leaf.style.fontSize = size + "px";

        leavesContainer.appendChild(leaf);
    });
}



const openTreeBtn = document.getElementById("openTreeBtn");
if (openTreeBtn) openTreeBtn.addEventListener("click", loadTreeModal);



async function loadTreeModal() {
    try {
        const user = JSON.parse(localStorage.getItem("user"));

        let trees = await fetchTreeByUser(user.id);
        let tree;

        if (!trees || trees.length === 0) {
            const res = await fetch("http://localhost:8080/api/v1/gratitudetrees", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    name: "Mi Árbol de Gratitud",
                    gratitudeWords: ["Vida", "Salud", "Familia"],
                    user: { id: user.id }
                })
            });
            tree = await res.json();
        } else {
            tree = trees[0];
        }

        drawLeaves(tree.gratitudeWords);
        document.getElementById("treeModal").classList.remove("hidden");

    } catch (err) {
        console.error("Error cargando árbol:", err);
        alert("No se pudo cargar el árbol.");
    }
}



async function loadUserProfile() {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return;

    try {
        const res = await fetch(`http://localhost:8080/api/v1/profiles/user/${user.id}`);

        if (res.status === 404) {
            console.warn("Este usuario no tiene perfil aún. Se creará uno vacío.");
            await createDefaultProfile(user.id);
            return await loadUserProfile();
        }

        const p = await res.json();

        
        window.currentProfileId = p.id;

        
        document.getElementById("profileName").textContent = user.name;
        document.getElementById("profileBio").textContent = p.bio || "Sin biografía aún.";
        document.getElementById("profileLanguage").textContent = p.language;
        document.getElementById("profilePrivacy").textContent = p.privacy;

        const img = document.getElementById("profilePhoto");
        img.src = p.photoUrl && p.photoUrl.trim() !== "" 
                    ? p.photoUrl 
                    : "img/default-profile.png";

    } catch (err) {
        console.error("Error cargando perfil:", err);
    }
}



async function createDefaultProfile(userId) {
    try {
        const res = await fetch("http://localhost:8080/api/v1/profiles", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                language: "es",
                privacy: "public",
                photoUrl: "",
                bio: "",
                user: { id: userId }
            })
        });

        return await res.json();
    } catch (err) {
        console.error("Error creando perfil por defecto:", err);
    }
}




const profileModal = document.getElementById("profileModal");
const editProfileBtn = document.getElementById("editProfileBtn");

if (editProfileBtn) {
    editProfileBtn.addEventListener("click", openProfileModal);
}

function openProfileModal() {

    document.getElementById("profileBioInput").value =
        document.getElementById("profileBio").textContent;

    const imgSrc = document.getElementById("profilePhoto").src;
    document.getElementById("profilePhotoInput").value = imgSrc.includes("default-profile")
        ? ""
        : imgSrc;

    document.getElementById("profileLanguageInput").value =
        document.getElementById("profileLanguage").textContent;

    document.getElementById("profilePrivacyInput").value =
        document.getElementById("profilePrivacy").textContent;

    profileModal.classList.remove("hidden");
}

function closeProfileModal() {
    profileModal.classList.add("hidden");
}



const profileForm = document.getElementById("profileForm");

if (profileForm) {
    profileForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const user = JSON.parse(localStorage.getItem("user"));
        if (!user) return;

        const payload = {
            language: document.getElementById("profileLanguageInput").value,
            privacy: document.getElementById("profilePrivacyInput").value,
            photoUrl: document.getElementById("profilePhotoInput").value,
            bio: document.getElementById("profileBioInput").value,
            user: { id: user.id }
        };

        try {
            await fetch(`http://localhost:8080/api/v1/profiles/${window.currentProfileId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            closeProfileModal();
            await loadUserProfile(); 

        } catch (err) {
            console.error("Error actualizando perfil:", err);
            alert("No se pudo guardar el perfil");
        }
    });
}



document.addEventListener("DOMContentLoaded", () => {
    loadUserProfile();
});



const capsuleList = document.getElementById("capsuleList");
const openCapsuleCreator = document.getElementById("openCapsuleCreator");
const capsuleCreatorModal = document.getElementById("capsuleCreatorModal");
const capsuleViewModal = document.getElementById("capsuleViewModal");


if (openCapsuleCreator) {
    openCapsuleCreator.addEventListener("click", () => {
        capsuleCreatorModal.classList.remove("hidden");
    });
}

function closeCapsuleCreator() {
    capsuleCreatorModal.classList.add("hidden");
}


function closeCapsuleView() {
    capsuleViewModal.classList.add("hidden");
}



async function loadCapsules() {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user || !capsuleList) return;

    try {
        const res = await fetch(`http://localhost:8080/api/v1/capsules/user/${user.id}`);
        const capsules = await res.json();

        capsuleList.innerHTML = "";

        if (!capsules || capsules.length === 0) {
            capsuleList.innerHTML = "<li class='empty-msg'>No tienes cápsulas aún.</li>";
            return;
        }

       
        capsules.sort((a, b) => new Date(a.openDate) - new Date(b.openDate));

        capsules.forEach(c => {
            const li = document.createElement("li");
            li.className = "capsule-item";

            const date = new Date(c.openDate).toLocaleDateString("es-CO");

            li.innerHTML = `
                <span class="capsule-title">${c.title}</span>
                <span class="capsule-date">${date}</span>
            `;

            
            li.addEventListener("click", () => openCapsule(c));

            capsuleList.appendChild(li);
        });

    } catch (err) {
        console.error("Error cargando cápsulas:", err);
    }
}



async function saveCapsule() {

    const title = document.getElementById("capsuleTitle").value.trim();
    const content = document.getElementById("capsuleContent").value.trim();
    const openDate = document.getElementById("capsuleOpenDate").value;

    const user = JSON.parse(localStorage.getItem("user"));

    if (!title || !content || !openDate) {
        alert("Todos los campos son obligatorios.");
        return;
    }

    try {
        await fetch("http://localhost:8080/api/v1/capsules", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                title,
                content,
                openDate,
                user: { id: user.id }
            })
        });

        closeCapsuleCreator();
        await loadCapsules();

    } catch (err) {
        console.error("Error guardando cápsula:", err);
        alert("No se pudo guardar la cápsula.");
    }
}



function openCapsule(capsule) {

    const today = new Date();
    const openDate = new Date(capsule.openDate);

    if (openDate > today) {
        alert("Todavía no puedes abrir esta cápsula ⏳");
        return;
    }

    document.getElementById("viewCapsuleTitle").textContent = capsule.title;
    document.getElementById("viewCapsuleContent").textContent = capsule.content;
    document.getElementById("viewCapsuleDate").textContent =
        "Abierta el " + openDate.toLocaleDateString("es-CO");

    capsuleViewModal.classList.remove("hidden");
}



document.addEventListener("DOMContentLoaded", () => {
    loadCapsules();
});




