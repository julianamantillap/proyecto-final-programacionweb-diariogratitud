package com.diariogratitud.diariogratitud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiariogratitudApplicationTests {

	@Test
	void contextLoads() {
	}

}
