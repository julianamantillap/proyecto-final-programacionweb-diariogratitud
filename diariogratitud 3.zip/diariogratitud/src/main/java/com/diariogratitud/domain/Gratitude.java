package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.time.LocalDateTime;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "gratitudes")
public class Gratitude {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String text;

    @Column(nullable = false)
    private String author;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-gratitudes")   
    private User user;

    @OneToMany(mappedBy = "gratitude", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "gratitude-comments")   
    private List<Comment> comments;

    @OneToMany(mappedBy = "gratitude", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "gratitude-likes")   
    private List<Like> likes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wall_id", nullable = true) 
     @JsonBackReference(value = "wall-gratitudes")
     private Wall wall;



    public Gratitude(String text, String author) {
        this.text = text;
        this.author = author;
    }

    public Gratitude(String text, String author, LocalDateTime createdAt, User user, Wall wall) {
        this.text = text;
        this.author = author;
        this.createdAt = createdAt;
        this.user = user;
        this.wall = wall;
    }
}
