package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.time.LocalDate;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "capsules")
public class Capsule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(name = "open_date", nullable = true)
    private LocalDate openDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-capsules")
    private User user;

    
    public Capsule(String title, String content, LocalDate openDate) {
        this.title = title;
        this.content = content;
        this.openDate = openDate;
    }

    public Capsule(String title, String content, LocalDate openDate, User user) {
        this.title = title;
        this.content = content;
        this.openDate = openDate;
        this.user = user;
    }
}
