package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "likes")
public class Like {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-likes")   
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "gratitude_id", nullable = false)
    @JsonBackReference(value = "gratitude-likes")   
    private Gratitude gratitude;

    public Like(User user, Gratitude gratitude) {
        this.user = user;
        this.gratitude = gratitude;
    }
}
