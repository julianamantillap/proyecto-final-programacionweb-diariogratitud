package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonBackReference;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "walls")
public class Wall {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_wall")
    private Integer id;

    @Column(nullable = false)
    private String name;

    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-walls")
    private User user;

    
    @OneToMany(mappedBy = "wall", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "wall-gratitudes")
    private List<Gratitude> gratitudes;

    @OneToOne(mappedBy = "wall", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "wall-wordcloud")
    private WordCloud wordCloud;

    
    @OneToMany(mappedBy = "wall", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "wall-floatingcards")
    private List<FloatingCard> floatingCards;

    public Wall(String name, User user) {
        this.name = name;
        this.user = user;
    }
}
