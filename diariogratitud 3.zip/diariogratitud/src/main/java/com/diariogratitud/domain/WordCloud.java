package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "word_clouds")
public class WordCloud {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_word_cloud")
    private Integer id;

    @Column(nullable = false)
    private String title;

    @ElementCollection
    @CollectionTable(name = "word_cloud_words", joinColumns = @JoinColumn(name = "word_cloud_id"))
    @Column(name = "word")
    private List<String> words;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wall_id", nullable = false)
    @JsonBackReference(value = "wall-wordcloud") 
    private Wall wall;

    public WordCloud(String title, List<String> words) {
        this.title = title;
        this.words = words;
    }
}




