package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;

import java.time.LocalDate;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "streaks")
public class Streak {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_streak")
    private Integer id;

    @Column(name = "days_count", nullable = false)
    private int daysCount;

    @Column(name = "last_update", nullable = false)
    private LocalDate lastUpdate = LocalDate.now();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-streaks")
    private User user;

    public Streak(int daysCount, LocalDate lastUpdate) {
        this.daysCount = daysCount;
        this.lastUpdate = lastUpdate;
    }
}
