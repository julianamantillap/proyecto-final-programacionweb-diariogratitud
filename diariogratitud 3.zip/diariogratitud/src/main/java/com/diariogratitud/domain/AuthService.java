package com.diariogratitud.domain;

import com.diariogratitud.domain.User;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.utils.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepo userRepo;

    public User register(String name, String email, String password) {

      
        if (userRepo.findByEmail(email).isPresent()) {
            throw new RuntimeException("Email already registered");
        }

       
        String encryptedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        User user = new User(name, email, encryptedPassword);

        return userRepo.save(user);
    }

    public User login(String email, String password) {

        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Email not found"));

       
        if (!BCrypt.checkpw(password, user.getPassword())) {
            throw new RuntimeException("Incorrect password");
        }

        return user;
    }
}

