package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;

import java.time.LocalDateTime;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String text;

    @Column(nullable = false)
    private String author;

    @Column(nullable = false)
    private LocalDateTime date = LocalDateTime.now();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "gratitude_id", nullable = false)
    @JsonBackReference(value = "gratitude-comments")
    private Gratitude gratitude;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-comments")
    private User user;

    
    public Comment(String text, String author, LocalDateTime date) {
        this.text = text;
        this.author = author;
        this.date = date;
    }

    
    public Comment(String text, String author, LocalDateTime date, User user, Gratitude gratitude) {
        this.text = text;
        this.author = author;
        this.date = date;
        this.user = user;
        this.gratitude = gratitude;
    }
}
