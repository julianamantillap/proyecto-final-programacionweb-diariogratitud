package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "floating_cards")
public class FloatingCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String message;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wall_id", nullable = false)
    @JsonBackReference(value = "wall-floatingcards")
    private Wall wall;

    
    public FloatingCard(String message) {
        this.message = message;
    }

    
    public FloatingCard(String message, Wall wall) {
        this.message = message;
        this.wall = wall;
    }
}


