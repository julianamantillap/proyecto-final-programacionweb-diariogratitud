package com.diariogratitud.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonBackReference;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "gratitude_trees")
public class GratitudeTree {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "tree_words", joinColumns = @JoinColumn(name = "tree_id"))
    @Column(name = "word", nullable = false)
    private List<String> gratitudeWords;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-trees")   
    private User user;

    public GratitudeTree(String name, List<String> gratitudeWords, User user) {
        this.name = name;
        this.gratitudeWords = gratitudeWords;
        this.user = user;
    }
}


