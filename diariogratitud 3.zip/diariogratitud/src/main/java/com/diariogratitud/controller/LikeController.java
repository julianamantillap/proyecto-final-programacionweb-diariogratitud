package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.diariogratitud.domain.Like;
import com.diariogratitud.domain.User;
import com.diariogratitud.domain.Gratitude;
import com.diariogratitud.repo.LikeRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.repo.GratitudeRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/likes")
public class LikeController {

    @Autowired
    private LikeRepo likeRepository;

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private GratitudeRepo gratitudeRepository;

    @GetMapping
    public List<Like> getAllLikes() {
        return likeRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Like> getLikeById(@PathVariable Integer id) {
        Like like = likeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Like not found for this id :: " + id));
        return ResponseEntity.ok().body(like);
    }

    @PostMapping
    public Like createLike(@RequestBody Like like) {
        Integer userId = like.getUser() != null ? like.getUser().getId() : null;
        Integer gratitudeId = like.getGratitude() != null ? like.getGratitude().getId() : null;

        if (userId == null || gratitudeId == null) {
            throw new ResourceNotFoundException("User and Gratitude must be provided.");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
        Gratitude gratitude = gratitudeRepository.findById(gratitudeId)
                .orElseThrow(() -> new ResourceNotFoundException("Gratitude not found for this id :: " + gratitudeId));

        like.setUser(user);
        like.setGratitude(gratitude);
        return likeRepository.save(like);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Like> updateLike(@PathVariable Integer id, @RequestBody Like likeDetails) {
        Like like = likeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Like not found for this id :: " + id));

        if (likeDetails.getUser() != null) {
            Integer userId = likeDetails.getUser().getId();
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
            like.setUser(user);
        }

        if (likeDetails.getGratitude() != null) {
            Integer gratitudeId = likeDetails.getGratitude().getId();
            Gratitude gratitude = gratitudeRepository.findById(gratitudeId)
                    .orElseThrow(() -> new ResourceNotFoundException("Gratitude not found for this id :: " + gratitudeId));
            like.setGratitude(gratitude);
        }

        Like updatedLike = likeRepository.save(like);
        return ResponseEntity.ok(updatedLike);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteLike(@PathVariable Integer id) {
        Like like = likeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Like not found for this id :: " + id));

        likeRepository.delete(like);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

    @GetMapping("/user/{userId}")
    public List<Like> getLikesByUser(@PathVariable Integer userId) {
        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
        return likeRepository.findByUserId(userId);
    }

    @GetMapping("/gratitude/{gratitudeId}")
    public List<Like> getLikesByGratitude(@PathVariable Integer gratitudeId) {
        gratitudeRepository.findById(gratitudeId)
                .orElseThrow(() -> new ResourceNotFoundException("Gratitude not found for this id :: " + gratitudeId));
        return likeRepository.findByGratitudeId(gratitudeId);
    }

    @GetMapping("/count/gratitude/{gratitudeId}")
    public Map<String, Integer> countLikesByGratitude(@PathVariable Integer gratitudeId) {
        gratitudeRepository.findById(gratitudeId)
                .orElseThrow(() -> new ResourceNotFoundException("Gratitude not found for this id :: " + gratitudeId));
        Integer count = likeRepository.countByGratitudeId(gratitudeId);
        Map<String, Integer> response = new HashMap<>();
        response.put("likes_count", count);
        return response;
    }

    @DeleteMapping("/user/{userId}/gratitude/{gratitudeId}")
    public Map<String, Boolean> deleteByUserAndGratitude(@PathVariable Integer userId,
                                                         @PathVariable Integer gratitudeId) {
        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
        gratitudeRepository.findById(gratitudeId)
                .orElseThrow(() -> new ResourceNotFoundException("Gratitude not found for this id :: " + gratitudeId));

        int affected = likeRepository.deleteByUserIdAndGratitudeId(userId, gratitudeId);
        if (affected == 0) {
            throw new ResourceNotFoundException(
                    "Like not found for userId :: " + userId + " and gratitudeId :: " + gratitudeId);
        }
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
}
