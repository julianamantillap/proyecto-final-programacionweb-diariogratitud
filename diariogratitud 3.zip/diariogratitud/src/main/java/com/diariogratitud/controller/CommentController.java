package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.diariogratitud.domain.Comment;
import com.diariogratitud.repo.CommentRepo;
import com.diariogratitud.repo.GratitudeRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/comments")
public class CommentController {

    @Autowired
    private CommentRepo commentRepository;

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private GratitudeRepo gratitudeRepository;

    @GetMapping
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Comment> getCommentById(@PathVariable Integer id) {
        Comment comment = commentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Comment not found for this id :: " + id));
        return ResponseEntity.ok().body(comment);
    }

    @PostMapping
    public Comment createComment(@RequestBody Comment comment) {
        if (comment.getDate() == null) {
            comment.setDate(LocalDateTime.now());
        }
        return commentRepository.save(comment);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Comment> updateComment(
            @PathVariable Integer id,
            @RequestBody Comment commentDetails) {

        Comment comment = commentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Comment not found for this id :: " + id));

        comment.setText(commentDetails.getText());
        comment.setAuthor(commentDetails.getAuthor());
        comment.setDate(LocalDateTime.now());

        final Comment updatedComment = commentRepository.save(comment);
        return ResponseEntity.ok(updatedComment);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteComment(@PathVariable Integer id) {
        Comment comment = commentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Comment not found for this id :: " + id));

        commentRepository.delete(comment);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

    @GetMapping("/user/{userId}")
    public List<Comment> getCommentsByUser(@PathVariable Integer userId) {
        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
        return commentRepository.findByUserId(userId);
    }

    @GetMapping("/gratitude/{gratitudeId}")
    public List<Comment> getCommentsByGratitude(@PathVariable Integer gratitudeId) {
        gratitudeRepository.findById(gratitudeId)
                .orElseThrow(() -> new ResourceNotFoundException("Gratitude not found for this id :: " + gratitudeId));
        return commentRepository.findByGratitudeId(gratitudeId);
    }

    @GetMapping("/search")
    public List<Comment> searchCommentsByAuthor(@RequestParam String author) {
        return commentRepository.findByAuthorContainingIgnoreCase(author);
    }

    @GetMapping("/date-range")
    public List<Comment> getCommentsByDateRange(@RequestParam String startDate,
                                                @RequestParam String endDate) {
        LocalDateTime start = LocalDateTime.parse(startDate);
        LocalDateTime end = LocalDateTime.parse(endDate);
        return commentRepository.findByDateBetween(start, end);
    }

    @GetMapping("/count")
    public Map<String, Integer> getCommentsCount() {
        Integer count = (int) commentRepository.count();
        Map<String, Integer> response = new HashMap<>();
        response.put("total_comments", count);
        return response;
    }
}
