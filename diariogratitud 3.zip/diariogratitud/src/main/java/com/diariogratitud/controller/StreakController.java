package com.diariogratitud.controller;

import com.diariogratitud.domain.Streak;
import com.diariogratitud.repo.StreakRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.domain.User;
import com.diariogratitud.utils.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/streaks")
public class StreakController {

    @Autowired
    private StreakRepo streakRepository;

    @Autowired
    private UserRepo userRepository;

    @GetMapping
    public List<Streak> getAllStreaks() {
        return streakRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Streak> getStreakById(@PathVariable Integer id) {
        Streak streak = streakRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Streak not found :: " + id));
        return ResponseEntity.ok(streak);
    }

    @PostMapping
    public Streak createStreak(@RequestBody Streak streak) {
        if (streak.getUser() != null && streak.getUser().getId() != null) {
            User user = userRepository.findById(streak.getUser().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found :: " + streak.getUser().getId()));
            streak.setUser(user);
        }
        return streakRepository.save(streak);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Streak> updateStreak(
            @PathVariable Integer id,
            @RequestBody Streak streakDetails) {

        Streak streak = streakRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Streak not found :: " + id));

        streak.setDaysCount(streakDetails.getDaysCount());
        streak.setLastUpdate(streakDetails.getLastUpdate());

        if (streakDetails.getUser() != null && streakDetails.getUser().getId() != null) {
            User user = userRepository.findById(streakDetails.getUser().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found :: " + streakDetails.getUser().getId()));
            streak.setUser(user);
        }

        Streak updated = streakRepository.save(streak);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteStreak(@PathVariable Integer id) {
        Streak streak = streakRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Streak not found :: " + id));

        streakRepository.delete(streak);

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", true);

        return response;
    }

    @GetMapping("/user/{userId}")
    public List<Streak> getStreaksByUser(@PathVariable Integer userId) {
        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found :: " + userId));

        return streakRepository.findByUserId(userId);
    }

    @GetMapping("/active/{minDays}")
    public List<Streak> getActive(@PathVariable int minDays) {
        return streakRepository.findByDaysCountGreaterThan(minDays);
    }
}
