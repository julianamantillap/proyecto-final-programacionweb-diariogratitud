package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.diariogratitud.domain.Capsule;
import com.diariogratitud.domain.User;
import com.diariogratitud.repo.CapsuleRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.utils.ResourceNotFoundException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/capsules")
public class CapsuleController {

  @Autowired
  private CapsuleRepo capsuleRepository;

  @Autowired
  private UserRepo userRepository;

  
  @GetMapping
  public List<Capsule> getAllCapsules() {
    return capsuleRepository.findAll();
  }

  @GetMapping("/{id}")
  public ResponseEntity<Capsule> getCapsuleById(@PathVariable Integer id) {
    Capsule capsule = capsuleRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Capsule not found for this id :: " + id));
    return ResponseEntity.ok().body(capsule);
  }

  @PostMapping
  public Capsule createCapsule(@RequestBody Capsule capsule) {
    return capsuleRepository.save(capsule);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Capsule> updateCapsule(@PathVariable Integer id,
      @RequestBody Capsule capsuleDetails) {
    Capsule capsule = capsuleRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Capsule not found for this id :: " + id));

    capsule.setTitle(capsuleDetails.getTitle());
    capsule.setContent(capsuleDetails.getContent());
    capsule.setOpenDate(capsuleDetails.getOpenDate());
    capsule.setUser(capsuleDetails.getUser());

    final Capsule updatedCapsule = capsuleRepository.save(capsule);
    return ResponseEntity.ok(updatedCapsule);
  }

  @DeleteMapping("/{id}")
  public Map<String, Boolean> deleteCapsule(@PathVariable Integer id) {
    Capsule capsule = capsuleRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Capsule not found for this id :: " + id));

    capsuleRepository.delete(capsule);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }

  
  @GetMapping("/user/{userId}")
  public List<Capsule> getCapsulesByUserId(@PathVariable Integer userId) {
    User user = userRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
    return capsuleRepository.findByUserId(userId);
  }

  @GetMapping("/search")
  public List<Capsule> searchCapsulesByTitle(@RequestParam String title) {
    return capsuleRepository.findByTitleContainingIgnoreCase(title);
  }

  @GetMapping("/open-date-range")
  public List<Capsule> getCapsulesByOpenDateRange(@RequestParam String startDate,
      @RequestParam String endDate) {
    LocalDate start = LocalDate.parse(startDate);
    LocalDate end = LocalDate.parse(endDate);
    return capsuleRepository.findByOpenDateBetween(start, end);
  }

  @GetMapping("/available")
  public List<Capsule> getAvailableCapsules() {
    LocalDate today = LocalDate.now();
    return capsuleRepository.findByOpenDateBeforeOrEqual(today);
  }
}
