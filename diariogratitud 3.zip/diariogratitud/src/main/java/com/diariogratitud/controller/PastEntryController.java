package com.diariogratitud.controller;

import com.diariogratitud.domain.PastEntry;
import com.diariogratitud.repo.PastEntryRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/pastentries")
public class PastEntryController {

    @Autowired
    private PastEntryRepo pastEntryRepository;

    @GetMapping
    public List<PastEntry> getAllPastEntries() {
        return pastEntryRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PastEntry> getPastEntryById(@PathVariable Integer id) {
        PastEntry entry = pastEntryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PastEntry not found :: " + id));
        return ResponseEntity.ok().body(entry);
    }

    @PostMapping
    public PastEntry createPastEntry(@RequestBody PastEntry entry) {
        entry.setPublishedAt(LocalDateTime.now());
        return pastEntryRepository.save(entry);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PastEntry> updatePastEntry(@PathVariable Integer id,
                                                     @RequestBody PastEntry details) {

        PastEntry entry = pastEntryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PastEntry not found :: " + id));

        entry.setTitle(details.getTitle());
        entry.setContent(details.getContent());
        entry.setPublishedAt(details.getPublishedAt());

        PastEntry updated = pastEntryRepository.save(entry);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deletePastEntry(@PathVariable Integer id) {
        PastEntry entry = pastEntryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PastEntry not found :: " + id));

        pastEntryRepository.delete(entry);

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", true);
        return response;
    }

    @GetMapping("/range")
    public List<PastEntry> getEntriesByDateRange(
            @RequestParam String start,
            @RequestParam String end) {

        LocalDateTime s = LocalDateTime.parse(start);
        LocalDateTime e = LocalDateTime.parse(end + "T23:59:59");

        return pastEntryRepository.findByDateRange(s, e);
    }
}
