package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.diariogratitud.domain.FloatingCard;
import com.diariogratitud.domain.Wall;
import com.diariogratitud.repo.FloatingCardRepo;
import com.diariogratitud.repo.WallRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/floatingcards")
public class FloatingCardController {

  @Autowired
  private FloatingCardRepo floatingCardRepository;

  @Autowired
  private WallRepo wallRepository;

  @GetMapping
  public List<FloatingCard> getAllFloatingCards() {
    return floatingCardRepository.findAll();
  }

  @GetMapping("/{id}")
  public ResponseEntity<FloatingCard> getFloatingCardById(@PathVariable Integer id) {
    FloatingCard card = floatingCardRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("FloatingCard not found for this id :: " + id));
    return ResponseEntity.ok().body(card);
  }

  @PostMapping
  public FloatingCard createFloatingCard(@RequestBody FloatingCard card) {
    return floatingCardRepository.save(card);
  }

  @PutMapping("/{id}")
  public ResponseEntity<FloatingCard> updateFloatingCard(@PathVariable Integer id,
      @RequestBody FloatingCard cardDetails) {
    FloatingCard card = floatingCardRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("FloatingCard not found for this id :: " + id));

    card.setMessage(cardDetails.getMessage());
    card.setWall(cardDetails.getWall());

    final FloatingCard updatedCard = floatingCardRepository.save(card);
    return ResponseEntity.ok(updatedCard);
  }

  @DeleteMapping("/{id}")
  public Map<String, Boolean> deleteFloatingCard(@PathVariable Integer id) {
    FloatingCard card = floatingCardRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("FloatingCard not found for this id :: " + id));

    floatingCardRepository.delete(card);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }


  @GetMapping("/search")
  public List<FloatingCard> searchFloatingCardsByMessage(@RequestParam String message) {
    return floatingCardRepository.findByMessageContainingIgnoreCase(message);
  }


  @GetMapping("/wall/{wallId}")
  public List<FloatingCard> getCardsByWall(@PathVariable Integer wallId) {
    wallRepository.findById(wallId)
        .orElseThrow(() -> new ResourceNotFoundException("Wall not found for this id :: " + wallId));
    return floatingCardRepository.findByWallId(wallId);
  }


  @GetMapping("/count/wall/{wallId}")
  public Map<String, Integer> countCardsByWall(@PathVariable Integer wallId) {
    wallRepository.findById(wallId)
        .orElseThrow(() -> new ResourceNotFoundException("Wall not found for this id :: " + wallId));
    Integer count = floatingCardRepository.countByWallId(wallId);
    Map<String, Integer> response = new HashMap<>();
    response.put("total_cards", count);
    return response;
  }

  @DeleteMapping("/wall/{wallId}")
  public Map<String, Boolean> deleteCardsByWall(@PathVariable Integer wallId) {
    wallRepository.findById(wallId)
        .orElseThrow(() -> new ResourceNotFoundException("Wall not found for this id :: " + wallId));

    floatingCardRepository.deleteByWallId(wallId);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted_all", Boolean.TRUE);
    return response;
  }
}

