package com.diariogratitud.controller;

import com.diariogratitud.domain.Achievement;
import com.diariogratitud.domain.User;
import com.diariogratitud.repo.AchievementRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/achievements")
public class AchievementController {

    @Autowired
    private AchievementRepo achievementRepository;

    @Autowired
    private UserRepo userRepository;

    @GetMapping("/user/{userId}")
    public List<Achievement> getAchievementsByUser(@PathVariable Integer userId) {
        userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found :: " + userId));

        return achievementRepository.findByUserId(userId);
    }

    @PostMapping
    public Achievement createAchievement(@RequestBody Map<String, Object> body) {
        String description = (String) body.get("description");
        Integer userId = (Integer) body.get("userId");

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found :: " + userId));

        Achievement a = new Achievement();
        a.setDescription(description);
        a.setDate(LocalDate.now());
        a.setUser(user);

        return achievementRepository.save(a);
    }
}

