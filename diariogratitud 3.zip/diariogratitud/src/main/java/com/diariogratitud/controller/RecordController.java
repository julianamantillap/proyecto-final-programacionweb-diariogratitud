package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.diariogratitud.domain.Record;
import com.diariogratitud.repo.RecordRepo;
import com.diariogratitud.utils.ResourceNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/records")
public class RecordController {

  @Autowired
  private RecordRepo recordRepository;

  @GetMapping
  public List<Record> getAllRecords() {
    return recordRepository.findAll();
  }

  @GetMapping("/{id}")
  public ResponseEntity<Record> getRecordById(@PathVariable Integer id) {
    Record record = recordRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Record not found for this id :: " + id));
    return ResponseEntity.ok().body(record);
  }

  @PostMapping
  public Record createRecord(@RequestBody Record record) {
    return recordRepository.save(record);
  }

 
  @PutMapping("/{id}")
  public ResponseEntity<Record> updateRecord(@PathVariable Integer id, @RequestBody Record recordDetails) {
    Record record = recordRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Record not found for this id :: " + id));

    record.setTitle(recordDetails.getTitle());
    record.setContent(recordDetails.getContent());
    record.setCreatedAt(recordDetails.getCreatedAt());
    record.setUser(recordDetails.getUser());

    Record updatedRecord = recordRepository.save(record);
    return ResponseEntity.ok(updatedRecord);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Map<String, Boolean>> deleteRecord(@PathVariable Integer id) {
    Record record = recordRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Record not found for this id :: " + id));

    recordRepository.delete(record);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return ResponseEntity.ok(response);
  }

  @GetMapping("/search/title")
  public List<Record> searchRecordsByTitle(@RequestParam String title) {
    return recordRepository.findByTitleContainingIgnoreCase(title);
  }


  @GetMapping("/search/content")
  public List<Record> searchRecordsByContent(@RequestParam String content) {
    return recordRepository.findByContentContainingIgnoreCase(content);
  }

  @GetMapping("/user/{userId}")
  public List<Record> getRecordsByUser(@PathVariable Integer userId) {
    return recordRepository.findByUserId(userId);
  }

  @GetMapping("/count")
  public Map<String, Object> countRecords() {
    long count = recordRepository.count();
    Map<String, Object> response = new HashMap<>();
    response.put("total_records", count);
    return response;
  }
}
