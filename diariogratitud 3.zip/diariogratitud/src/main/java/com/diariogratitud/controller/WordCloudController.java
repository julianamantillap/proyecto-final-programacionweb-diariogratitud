package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.diariogratitud.domain.WordCloud;
import com.diariogratitud.repo.WordCloudRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/wordclouds")
public class WordCloudController {

  @Autowired
  private WordCloudRepo wordCloudRepository;

  @GetMapping
  public List<WordCloud> getAllWordClouds() {
    return wordCloudRepository.findAll();
  }


  @GetMapping("/{id}")
  public ResponseEntity<WordCloud> getWordCloudById(@PathVariable Integer id) {
    WordCloud cloud = wordCloudRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("WordCloud not found for this id :: " + id));
    return ResponseEntity.ok().body(cloud);
  }

  @PostMapping
  public WordCloud createWordCloud(@RequestBody WordCloud cloud) {
    return wordCloudRepository.save(cloud);
  }

  @PutMapping("/{id}")
  public ResponseEntity<WordCloud> updateWordCloud(@PathVariable Integer id,
      @RequestBody WordCloud cloudDetails) {
    WordCloud cloud = wordCloudRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("WordCloud not found for this id :: " + id));

    cloud.setTitle(cloudDetails.getTitle());
    cloud.setWords(cloudDetails.getWords());
    cloud.setWall(cloudDetails.getWall());

    final WordCloud updatedCloud = wordCloudRepository.save(cloud);
    return ResponseEntity.ok(updatedCloud);
  }


  @DeleteMapping("/{id}")
  public Map<String, Boolean> deleteWordCloud(@PathVariable Integer id) {
    WordCloud cloud = wordCloudRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("WordCloud not found for this id :: " + id));

    wordCloudRepository.delete(cloud);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }
}
