package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.diariogratitud.domain.GratitudeTree;
import com.diariogratitud.domain.User;
import com.diariogratitud.repo.GratitudeTreeRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/gratitudetrees")
public class GratitudeTreeController {

  @Autowired
  private GratitudeTreeRepo gratitudeTreeRepository;

  @Autowired
  private UserRepo userRepository;

  
  @GetMapping
  public List<GratitudeTree> getAllGratitudeTrees() {
    return gratitudeTreeRepository.findAll();
  }

  
  @GetMapping("/{id}")
  public ResponseEntity<GratitudeTree> getGratitudeTreeById(@PathVariable Integer id) {
    GratitudeTree tree = gratitudeTreeRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("GratitudeTree not found for this id :: " + id));
    return ResponseEntity.ok().body(tree);
  }


  @PostMapping
  public GratitudeTree createGratitudeTree(@RequestBody GratitudeTree tree) {
    return gratitudeTreeRepository.save(tree);
  }


  @PutMapping("/{id}")
public ResponseEntity<GratitudeTree> updateGratitudeTree(
        @PathVariable Integer id,
        @RequestParam Integer userId,
        @RequestBody GratitudeTree treeDetails) {

    GratitudeTree tree = gratitudeTreeRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("GratitudeTree not found for this id :: " + id));


    User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    tree.setName(treeDetails.getName());
    tree.setGratitudeWords(treeDetails.getGratitudeWords());
    tree.setUser(user);

    GratitudeTree updatedTree = gratitudeTreeRepository.save(tree);
    return ResponseEntity.ok(updatedTree);
}


  @DeleteMapping("/{id}")
  public Map<String, Boolean> deleteGratitudeTree(@PathVariable Integer id) {
    GratitudeTree tree = gratitudeTreeRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("GratitudeTree not found for this id :: " + id));

    gratitudeTreeRepository.delete(tree);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }


  @GetMapping("/search")
  public List<GratitudeTree> searchTreesByName(@RequestParam String name) {
    return gratitudeTreeRepository.findByNameContainingIgnoreCase(name);
  }

  @GetMapping("/user/{userId}")
  public List<GratitudeTree> getTreesByUser(@PathVariable Integer userId) {
    userRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
    return gratitudeTreeRepository.findByUserId(userId);
  }

  
  @GetMapping("/count/user/{userId}")
  public Map<String, Integer> countTreesByUser(@PathVariable Integer userId) {
    userRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
    Integer count = gratitudeTreeRepository.countByUserId(userId);
    Map<String, Integer> response = new HashMap<>();
    response.put("tree_count", count);
    return response;
  }


  @GetMapping("/min-words/{count}")
  public List<GratitudeTree> getTreesWithMinWords(@PathVariable int count) {
    return gratitudeTreeRepository.findTreesWithMinWords(count);
  }

  @GetMapping("/ordered-by-words")
  public List<GratitudeTree> getTreesOrderedByWordCount() {
    return gratitudeTreeRepository.findAllOrderedByWordCountDesc();
  }

  @GetMapping("/user-auto/{userId}")
public ResponseEntity<GratitudeTree> getOrCreateTree(@PathVariable Integer userId) {

    User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    List<GratitudeTree> existing = gratitudeTreeRepository.findByUserId(userId);

    if (!existing.isEmpty()) {
        return ResponseEntity.ok(existing.get(0));
    }

    GratitudeTree newTree = new GratitudeTree();
    newTree.setUser(user);
    newTree.setName("Mi Árbol de Gratitud");
    newTree.setGratitudeWords(List.of());

    return ResponseEntity.ok(gratitudeTreeRepository.save(newTree));
}

}
