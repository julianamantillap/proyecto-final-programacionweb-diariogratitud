package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.diariogratitud.domain.Profile;
import com.diariogratitud.repo.ProfileRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/profiles")
public class ProfileController {

  @Autowired
  private ProfileRepo profileRepository;

  @PersistenceContext
  private EntityManager entityManager;


  @GetMapping
  public List<Profile> getAllProfiles() {
    return profileRepository.findAll();
  }

  @GetMapping("/{id}")
  public ResponseEntity<Profile> getProfileById(@PathVariable Integer id) {
    Profile profile = profileRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Profile not found for this id :: " + id));
    return ResponseEntity.ok().body(profile);
  }


  @PostMapping
  public Profile createProfile(@RequestBody Profile profile) {
    return profileRepository.save(profile);
  }

 
  @PutMapping("/{id}")
  public ResponseEntity<Profile> updateProfile(@PathVariable Integer id, @RequestBody Profile profileDetails) {
    Profile profile = profileRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Profile not found for this id :: " + id));

    profile.setLanguage(profileDetails.getLanguage());
    profile.setPrivacy(profileDetails.getPrivacy());
    profile.setPhotoUrl(profileDetails.getPhotoUrl());
    profile.setBio(profileDetails.getBio());
    profile.setUser(profileDetails.getUser());

    Profile updatedProfile = profileRepository.save(profile);
    return ResponseEntity.ok(updatedProfile);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Map<String, Boolean>> deleteProfile(@PathVariable Integer id) {
    Profile profile = profileRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Profile not found for this id :: " + id));

    profileRepository.delete(profile);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return ResponseEntity.ok(response);
  }

  
  @GetMapping("/language/{language}")
  public List<Profile> getProfilesByLanguage(@PathVariable String language) {
    return profileRepository.findByLanguageIgnoreCase(language);
  }

  @GetMapping("/privacy/{privacy}")
  public List<Profile> getProfilesByPrivacy(@PathVariable String privacy) {
    return profileRepository.findByPrivacyIgnoreCase(privacy);
  }

  @GetMapping("/search")
  public List<Profile> searchProfilesByBio(@RequestParam String keyword) {
    return profileRepository.findByBioContainingIgnoreCase(keyword);
  }

 @GetMapping("/user/{userId}")
public ResponseEntity<Profile> getProfileByUserId(@PathVariable Integer userId) {

    com.diariogratitud.domain.User user = entityManager
            .find(com.diariogratitud.domain.User.class, userId);

    if (user == null) {
        throw new ResourceNotFoundException("User not found with id :: " + userId);
    }

    var existing = profileRepository.findByUserId(userId);

    Profile profile = existing.orElseGet(() -> {
        Profile p = new Profile();
        p.setUser(user);
        p.setLanguage("es");
        p.setPrivacy("PUBLIC");
        p.setBio("Sin biografía aún.");
        p.setPhotoUrl(null);
        return profileRepository.save(p);
    });

    return ResponseEntity.ok(profile);
}



}
