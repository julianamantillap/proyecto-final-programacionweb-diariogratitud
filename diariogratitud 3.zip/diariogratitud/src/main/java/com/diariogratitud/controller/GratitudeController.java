package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.diariogratitud.domain.Gratitude;
import com.diariogratitud.domain.User;
import com.diariogratitud.repo.GratitudeRepo;
import com.diariogratitud.repo.UserRepo;
import com.diariogratitud.utils.ResourceNotFoundException;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/gratitudes")
public class GratitudeController {

    @Autowired
    private GratitudeRepo gratitudeRepository;

    @Autowired
    private UserRepo userRepository;

    
    @GetMapping
    public List<Gratitude> getAllGratitudes() {
        return gratitudeRepository.findAll();
    }

   
    @GetMapping("/{id}")
    public ResponseEntity<Gratitude> getGratitudeById(@PathVariable Integer id) {
        Gratitude g = gratitudeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Not found :: " + id));
        return ResponseEntity.ok().body(g);
    }

   
    @PostMapping
    public Gratitude createGratitude(@RequestBody Map<String, Object> body) {

        String text = (String) body.get("text");
        String author = (String) body.get("author");

        Map<String, Object> userMap = (Map<String, Object>) body.get("user");
        if (userMap == null || userMap.get("id") == null) {
            throw new ResourceNotFoundException("User data missing");
        }

        Integer userId = (Integer) userMap.get("id");

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found :: " + userId));

        Gratitude g = new Gratitude();
        g.setText(text);
        g.setAuthor(author);
        g.setCreatedAt(LocalDateTime.now());
        g.setUser(user);

        
        g.setWall(null);

        return gratitudeRepository.save(g);
    }

   
    @PutMapping("/{id}")
    public ResponseEntity<Gratitude> updateGratitude(
            @PathVariable Integer id,
            @RequestBody Gratitude details) {

        Gratitude g = gratitudeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Not found :: " + id));

        g.setText(details.getText());
        g.setAuthor(details.getAuthor());
        g.setUser(details.getUser());
        g.setWall(details.getWall());

        Gratitude updated = gratitudeRepository.save(g);
        return ResponseEntity.ok(updated);
    }

    
    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteGratitude(@PathVariable Integer id) {
        Gratitude g = gratitudeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Not found :: " + id));

        gratitudeRepository.delete(g);

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", true);
        return response;
    }

    
    @GetMapping("/simple")
    public List<Map<String, Object>> getSimpleGratitudes() {

        List<Gratitude> list = gratitudeRepository.findAll();
        List<Map<String, Object>> clean = new ArrayList<>();

        for (Gratitude g : list) {

            Map<String, Object> m = new HashMap<>();
            m.put("id", g.getId());
            m.put("text", g.getText());
            m.put("author", g.getAuthor());
            m.put("createdAt", g.getCreatedAt());

            if (g.getUser() != null) {
                Map<String, Object> u = new HashMap<>();
                u.put("id", g.getUser().getId());
                u.put("name", g.getUser().getName());
                u.put("email", g.getUser().getEmail());
                m.put("user", u);
            } else {
                m.put("user", null);
            }

            clean.add(m);
        }

        return clean;
    }
}
