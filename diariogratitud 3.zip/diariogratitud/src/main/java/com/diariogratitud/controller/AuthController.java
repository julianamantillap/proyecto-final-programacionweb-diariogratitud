package com.diariogratitud.controller;

import com.diariogratitud.domain.User;
import com.diariogratitud.domain.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

   
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User userRequest) {
        try {
            User newUser = authService.register(
                    userRequest.getName(),
                    userRequest.getEmail(),
                    userRequest.getPassword()
            );
            return ResponseEntity.ok(newUser);

        } catch (Exception e) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error", e.getMessage()));
        }
    }

   
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User userRequest) {
        try {
            User user = authService.login(
                    userRequest.getEmail(),
                    userRequest.getPassword()
            );
            return ResponseEntity.ok(user);

        } catch (Exception e) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error", e.getMessage()));
        }
    }
}
