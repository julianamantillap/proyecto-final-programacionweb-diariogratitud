package com.diariogratitud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.diariogratitud.domain.Wall;
import com.diariogratitud.repo.WallRepo;
import com.diariogratitud.utils.ResourceNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RequestMapping("/api/v1/walls")
public class WallController {

  @Autowired
  private WallRepo wallRepository;

  @GetMapping
  public List<Wall> getAllWalls() {
    return wallRepository.findAll();
  }

 
  @GetMapping("/{id}")
  public ResponseEntity<Wall> getWallById(@PathVariable Integer id) {
    Wall wall = wallRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Wall not found for this id :: " + id));
    return ResponseEntity.ok().body(wall);
  }

  @PostMapping
  public Wall createWall(@RequestBody Wall wall) {
    return wallRepository.save(wall);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Wall> updateWall(@PathVariable Integer id, @RequestBody Wall wallDetails) {
    Wall wall = wallRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Wall not found for this id :: " + id));

    wall.setName(wallDetails.getName());
    wall.setUser(wallDetails.getUser());
    wall.setGratitudes(wallDetails.getGratitudes());
    wall.setWordCloud(wallDetails.getWordCloud());
    wall.setFloatingCards(wallDetails.getFloatingCards());

    final Wall updatedWall = wallRepository.save(wall);
    return ResponseEntity.ok(updatedWall);
  }

  @DeleteMapping("/{id}")
  public Map<String, Boolean> deleteWall(@PathVariable Integer id) {
    Wall wall = wallRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Wall not found for this id :: " + id));

    wallRepository.delete(wall);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }

  @GetMapping("/search")
  public List<Wall> searchWallsByName(@RequestParam String name) {
    return wallRepository.findByNameContainingIgnoreCase(name);
  }

  @GetMapping("/user/{userId}")
  public List<Wall> getWallsByUser(@PathVariable Integer userId) {
    return wallRepository.findByUserId(userId);
  }

  @GetMapping("/count/user/{userId}")
  public Map<String, Integer> countWallsByUser(@PathVariable Integer userId) {
    Integer count = wallRepository.countByUserId(userId);
    Map<String, Integer> response = new HashMap<>();
    response.put("total_walls", count);
    return response;
  }
}
