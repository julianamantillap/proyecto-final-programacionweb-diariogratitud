package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.GratitudeTree;

import java.util.List;
import java.util.Optional;


@Repository
public interface GratitudeTreeRepo extends JpaRepository<GratitudeTree, Integer> {

  Optional<GratitudeTree> findByName(String name);

  List<GratitudeTree> findByNameContainingIgnoreCase(String name);

  List<GratitudeTree> findByUserId(Integer userId);

  @Query("SELECT t FROM GratitudeTree t WHERE SIZE(t.gratitudeWords) >= :minWords")
  List<GratitudeTree> findTreesWithMinWords(@Param("minWords") int minWords);

  @Query("SELECT t FROM GratitudeTree t ORDER BY SIZE(t.gratitudeWords) DESC")
  List<GratitudeTree> findAllOrderedByWordCountDesc();

  @Query("SELECT COUNT(t) FROM GratitudeTree t WHERE t.user.id = :userId")
  Integer countByUserId(@Param("userId") Integer userId);
}



