package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.Streak;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface StreakRepo extends JpaRepository<Streak, Integer> {

    List<Streak> findByUserId(Integer userId);

    List<Streak> findByDaysCountGreaterThan(int minDays);

    @Query("SELECT s FROM Streak s WHERE s.lastUpdate >= :startDate AND s.lastUpdate <= :endDate")
    List<Streak> findByLastUpdateBetween(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

 
    @Query("SELECT s FROM Streak s WHERE s.lastUpdate = CURRENT_DATE")
    List<Streak> getTodayUpdatedStreaks();

    
    default List<Streak> findTodayUpdatedStreaks() {
        return getTodayUpdatedStreaks();
    }

    @Query("SELECT COUNT(s) FROM Streak s WHERE s.daysCount > :minDays")
    Integer countActiveStreaks(@Param("minDays") int minDays);

    List<Streak> findAllByOrderByDaysCountDesc();
}





