package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.Wall;

import java.util.List;
import java.util.Optional;


@Repository
public interface WallRepo extends JpaRepository<Wall, Integer> {

  Optional<Wall> findByName(String name);

  List<Wall> findByNameContainingIgnoreCase(String name);

  List<Wall> findByUserId(Integer userId);

  @Query("SELECT COUNT(w) FROM Wall w WHERE w.user.id = :userId")
  Integer countByUserId(@Param("userId") Integer userId);

  @Query("SELECT w FROM Wall w WHERE SIZE(w.gratitudes) >= :minGratitudes")
  List<Wall> findWallsWithMinGratitudes(@Param("minGratitudes") int minGratitudes);

  @Query("SELECT w FROM Wall w WHERE w.wordCloud IS NOT NULL")
  List<Wall> findWallsWithWordCloud();

  @Query("SELECT w FROM Wall w WHERE w.gratitudes IS EMPTY")
  List<Wall> findEmptyWalls();
}



