package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.Comment;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@Repository
public interface CommentRepo extends JpaRepository<Comment, Integer> {

  
  Optional<Comment> findByText(String text);

  List<Comment> findByUserId(Integer userId);

  List<Comment> findByGratitudeId(Integer gratitudeId);

  List<Comment> findByAuthorContainingIgnoreCase(String author);


  @Query("SELECT c FROM Comment c WHERE c.date BETWEEN :startDate AND :endDate")
  List<Comment> findByDateBetween(@Param("startDate") LocalDateTime startDate,
                                  @Param("endDate") LocalDateTime endDate);

  
  @Query("SELECT c FROM Comment c WHERE c.author IN :authors")
  List<Comment> findByAuthorsList(@Param("authors") List<String> authors);

  @Query("SELECT c.user.id, COUNT(c) FROM Comment c GROUP BY c.user.id")
  List<Object[]> countCommentsByUser();

  @Query("SELECT c.gratitude.id, COUNT(c) FROM Comment c GROUP BY c.gratitude.id")
  List<Object[]> countCommentsByGratitude();
}



