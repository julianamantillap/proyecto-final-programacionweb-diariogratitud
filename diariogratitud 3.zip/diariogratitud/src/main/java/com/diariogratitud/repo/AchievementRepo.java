package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.Achievement;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AchievementRepo extends JpaRepository<Achievement, Integer> {

    List<Achievement> findByDescriptionContainingIgnoreCase(String description);

    List<Achievement> findByDate(LocalDate date);

    List<Achievement> findByDateBetween(LocalDate start, LocalDate end);

    List<Achievement> findByUserId(Integer userId);
}




