package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.Capsule;

import java.time.LocalDate;
import java.util.List;


@Repository
public interface CapsuleRepo extends JpaRepository<Capsule, Integer> {

  List<Capsule> findByUserId(Integer userId);

  List<Capsule> findByTitleContainingIgnoreCase(String title);

  List<Capsule> findByOpenDate(LocalDate openDate);


  @Query("SELECT c FROM Capsule c WHERE c.openDate BETWEEN :startDate AND :endDate")
  List<Capsule> findByOpenDateBetween(@Param("startDate") LocalDate startDate,
                                      @Param("endDate") LocalDate endDate);

  
  @Query("SELECT c FROM Capsule c WHERE c.openDate <= :today")
  List<Capsule> findByOpenDateBeforeOrEqual(@Param("today") LocalDate today);

  
  @Query("SELECT c.user.id, COUNT(c) FROM Capsule c GROUP BY c.user.id")
  List<Object[]> countCapsulesByUser();

  @Query("SELECT YEAR(c.openDate) AS year, COUNT(c) AS count FROM Capsule c GROUP BY YEAR(c.openDate)")
  List<Object[]> countCapsulesByYear();

  @Query("SELECT c FROM Capsule c WHERE c.user IS NULL")
  List<Capsule> findOrphanCapsules();
}

