package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.PastEntry;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PastEntryRepo extends JpaRepository<PastEntry, Integer> {

    Optional<PastEntry> findByTitle(String title);

    List<PastEntry> findByTitleContainingIgnoreCase(String title);

    List<PastEntry> findByContentContainingIgnoreCase(String content);

  
    @Query("SELECT p FROM PastEntry p WHERE p.publishedAt >= :startDate AND p.publishedAt <= :endDate")
    List<PastEntry> findByDateRange(
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate
    );

    @Query("SELECT p FROM PastEntry p WHERE p.publishedAt >= :recentDate ORDER BY p.publishedAt DESC")
    List<PastEntry> findRecentEntries(@Param("recentDate") LocalDateTime recentDate);

    Integer countBy();
}





