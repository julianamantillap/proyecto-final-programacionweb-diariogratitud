package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.WordCloud;

import java.util.List;
import java.util.Optional;


@Repository
public interface WordCloudRepo extends JpaRepository<WordCloud, Integer> {

  Optional<WordCloud> findByTitle(String title);

  @Query("SELECT w FROM WordCloud w JOIN w.words word WHERE LOWER(word) LIKE LOWER(CONCAT('%', :keyword, '%'))")
  List<WordCloud> findByWordContaining(@Param("keyword") String keyword);

  List<WordCloud> findByWallId(Integer wallId);

  @Query("SELECT COUNT(w) FROM WordCloud w WHERE w.wall.id = :wallId")
  Integer countByWallId(@Param("wallId") Integer wallId);

  @Query("SELECT w FROM WordCloud w WHERE SIZE(w.words) > :minWords")
  List<WordCloud> findByMinWordCount(@Param("minWords") int minWords);

  @Query("SELECT w FROM WordCloud w WHERE w.words IS EMPTY")
  List<WordCloud> findEmptyWordClouds();
}


