package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.Gratitude;

import java.time.LocalDateTime;
import java.util.List;


@Repository
public interface GratitudeRepo extends JpaRepository<Gratitude, Integer> {

  List<Gratitude> findByAuthorContainingIgnoreCase(String author);

  List<Gratitude> findByUserId(Integer userId);

  List<Gratitude> findByTextContainingIgnoreCase(String text);

  @Query("SELECT g FROM Gratitude g WHERE g.createdAt BETWEEN :startDate AND :endDate")
  List<Gratitude> findByCreatedAtBetween(@Param("startDate") LocalDateTime startDate,
                                         @Param("endDate") LocalDateTime endDate);


  @Query("SELECT g FROM Gratitude g WHERE g.createdAt >= :lastWeek")
  List<Gratitude> findRecentGratitudes(@Param("lastWeek") LocalDateTime lastWeek);


  @Query("SELECT COUNT(g) FROM Gratitude g WHERE g.user.id = :userId")
  Integer countByUserId(@Param("userId") Integer userId);


  @Query("SELECT g FROM Gratitude g WHERE g.user IS NULL")
  List<Gratitude> findOrphanGratitudes();

  
  @Query("SELECT g.author, COUNT(g) FROM Gratitude g GROUP BY g.author")
  List<Object[]> countGratitudesByAuthor();

  
  @Query("SELECT g FROM Gratitude g WHERE g.wall.id = :wallId")
  List<Gratitude> findByWallId(@Param("wallId") Integer wallId);
}



