package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.diariogratitud.domain.Record;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@Repository
public interface RecordRepo extends JpaRepository<Record, Integer> {

 
  Optional<Record> findByTitle(String title);

  List<Record> findByTitleContainingIgnoreCase(String title);

  List<Record> findByContentContainingIgnoreCase(String content);

  List<Record> findByUserId(Integer userId);

  @Query("SELECT r FROM Record r WHERE r.createdAt BETWEEN :startDate AND :endDate")
  List<Record> findByCreatedAtRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);

  @Query("SELECT r FROM Record r WHERE r.createdAt >= :lastWeek ORDER BY r.createdAt DESC")
  List<Record> findRecentRecords(@Param("lastWeek") LocalDateTime lastWeek);

  @Query("SELECT r.user.id, COUNT(r) FROM Record r GROUP BY r.user.id")
  List<Object[]> countRecordsByUser();

  @Query("SELECT r FROM Record r WHERE r.user IS NULL")
  List<Record> findOrphanRecords();
}



