package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.FloatingCard;

import java.util.List;


@Repository
public interface FloatingCardRepo extends JpaRepository<FloatingCard, Integer> {

  List<FloatingCard> findByWallId(Integer wallId);

  List<FloatingCard> findByMessageContainingIgnoreCase(String message);

  @Query("SELECT COUNT(fc) FROM FloatingCard fc WHERE fc.wall.id = :wallId")
  Integer countByWallId(@Param("wallId") Integer wallId);

  @Query("DELETE FROM FloatingCard fc WHERE fc.wall.id = :wallId")
  void deleteByWallId(@Param("wallId") Integer wallId);

  @Query("SELECT fc FROM FloatingCard fc WHERE fc.wall IS NULL")
  List<FloatingCard> findOrphanCards();

  @Query("SELECT fc FROM FloatingCard fc WHERE LOWER(fc.message) LIKE LOWER(CONCAT('%', :keyword, '%'))")
  List<FloatingCard> searchByKeyword(@Param("keyword") String keyword);
}



