package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.diariogratitud.domain.Like;
import java.util.List;
import java.util.Optional;


@Repository
public interface LikeRepo extends JpaRepository<Like, Integer> {

    Optional<Like> findByUserIdAndGratitudeId(Integer userId, Integer gratitudeId);

    List<Like> findByUserId(Integer userId);

    List<Like> findByGratitudeId(Integer gratitudeId);

    Integer countByGratitudeId(Integer gratitudeId);

    int deleteByUserIdAndGratitudeId(Integer userId, Integer gratitudeId);

    @Query("""
           SELECT l FROM Like l
           JOIN l.user u
           JOIN l.gratitude g
           WHERE LOWER(g.author) LIKE LOWER(CONCAT('%', :searchTerm, '%'))
              OR LOWER(u.name) LIKE LOWER(CONCAT('%', :searchTerm, '%'))
           """)
    List<Like> findByAuthorOrNameContaining(@Param("searchTerm") String searchTerm);
}



