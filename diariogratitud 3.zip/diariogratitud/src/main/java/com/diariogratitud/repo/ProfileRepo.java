package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.diariogratitud.domain.Profile;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProfileRepo extends JpaRepository<Profile, Integer> {

  List<Profile> findByLanguageIgnoreCase(String language);
  List<Profile> findByPrivacyIgnoreCase(String privacy);
  List<Profile> findByBioContainingIgnoreCase(String keyword);
  Optional<Profile> findByUserId(Integer userId);


  @Query("SELECT p FROM Profile p WHERE LOWER(p.language) = LOWER(:language)")
  List<Profile> searchByLanguage(@Param("language") String language);

 
  @Query("SELECT p FROM Profile p WHERE LOWER(p.bio) LIKE LOWER(CONCAT('%', :kw, '%'))")
  List<Profile> searchByBioLike(@Param("kw") String keyword);

  
  @Query("SELECT p.privacy, COUNT(p) FROM Profile p GROUP BY p.privacy")
  List<Object[]> countProfilesByPrivacy();

  @Query("SELECT p FROM Profile p ORDER BY LENGTH(p.bio) DESC")
  List<Profile> findAllOrderByBioLengthDesc();
}





