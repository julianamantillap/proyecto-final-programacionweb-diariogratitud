package com.diariogratitud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.diariogratitud.domain.User;

import java.util.List;
import java.util.Optional;


@Repository
public interface UserRepo extends JpaRepository<User, Integer> {

  
  Optional<User> findByEmail(String email);

  
  List<User> findByNameContainingIgnoreCase(String name);

  
  @Query("SELECT u FROM User u WHERE LOWER(u.email) LIKE LOWER(CONCAT('%', :domain))")
  List<User> findByEmailDomain(@Param("domain") String domain);

  @Query("SELECT COUNT(u) FROM User u")
  Integer countTotalUsers();

  List<User> findAllByOrderByNameAsc();
}



